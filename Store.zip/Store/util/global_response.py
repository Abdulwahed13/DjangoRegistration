success_response = {"result": {}, "code": ""}

error_response = {
    "code" : "",
    "message" :"",
    "errors" : ""
}