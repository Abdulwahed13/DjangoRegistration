SUCCESS= {
    # Books
    'ADD_BOOK': "Book has been added",
    'UPDATE_BOOK': "Book has been updated",
    'DELETE_BOOK': "Book has been deleted",
    'GET_BOOK' : "The books are being displayed"
}

ERROR = {
    # generic
    'ID_NOT_EXIST': 'ID you mentioned does not exist',
    'FIELD_REQUIRED': "field is required",

    # Books
    'ADD_ERROR' : "addition of book has been failed",
    'UPDATE_ERROR' : "update was not succesful",
    'DELETE_ERROR' : "either the book does not exist or the name of the book is wrong",
    'GET_ERROR' : "either the book does not exist or the name of the book is wrong"
}