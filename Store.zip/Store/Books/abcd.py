from django.core.mail import send_mail
from django.conf import settings
from django.http import HttpResponse

def sendSimpleEmail(request):
    send_mail(
        'Subject here',
        'Here is the message.',
        from_email=settings.EMAIL_HOST_USER,
        recipient_list=['abdul@innomick.com'],
        fail_silently=False,
    )
    return HttpResponse('%s'%res)